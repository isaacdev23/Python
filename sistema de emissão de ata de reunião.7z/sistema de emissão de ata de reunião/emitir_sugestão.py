import csv
import os

def emitir_sugestao():
    sugestao = input("Digite a sugestão: ")

    with open("sugestoes.csv", "a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["Sugestão", sugestao])

    print("Sugestão enviada com sucesso!")

# ... (outras funções)

# Loop principal do programa
while True:
    exibir_menu()
    opcao = int(input("Escolha uma opção: "))

    if opcao == 1:
        emitir_sugestao()
    elif opcao == 2:
        emitir_sugestao()
    # ... (outras opções)
    elif opcao == 0:
        break
    else:
        print("Opção inválida. Tente novamente.")

