def emitir_ata():
    # Implemente a lógica para emissão de ata aqui
    print("Ata emitida com sucesso!")

def emitir_sugestao():
    # Implemente a lógica para emissão de sugestão aqui
    print("Sugestão enviada com sucesso!")

def concluir_ata():
    # Implemente a lógica para conclusão de ata aqui
    print("Ata concluída com sucesso!")

def consultar_ata():
    # Implemente a lógica para consulta de ata aqui
    print("Consulta de ata realizada com sucesso!")

def emitir_relatorio_tempo():
    # Implemente a lógica para emissão de relatório por tempo de reunião aqui
    print("Relatório por tempo de reunião emitido com sucesso!")

def emitir_relatorio_setor():
    # Implemente a lógica para emissão de relatório por setor aqui
    print("Relatório por setor emitido com sucesso!")

def emitir_relatorio_participante():
    # Implemente a lógica para emissão de relatório por participante aqui
    print("Relatório por participante emitido com sucesso!")

def exibir_menu():
    print("---- Menu ----")
    print("1. Emissão de Ata")
    print("2. Emissão de Sugestão")
    print("3. Conclusão de Ata")
    print("4. Consulta de Ata")
    print("5. Emissão de Relatório (por tempo de reunião)")
    print("6. Emissão de Relatório (por setor)")
    print("7. Emissão de Relatório (por participante)")
    print("0. Sair")

# Loop principal do programa
while True:
    exibir_menu()
    opcao = int(input("Escolha uma opção: "))

    if opcao == 1:
        emitir_ata()
    elif opcao == 2:
        emitir_sugestao()
    elif opcao == 3:
        concluir_ata()
    elif opcao == 4:
        consultar_ata()
    elif opcao == 5:
        emitir_relatorio_tempo()
    elif opcao == 6:
        emitir_relatorio_setor()
    elif opcao == 7:
        emitir_relatorio_participante()
    elif opcao == 0:
        break
    else:
        print("Opção inválida. Tente novamente.")
