def emitir_ata():
    print("----- Emissão de Ata -----")
    titulo = input("Digite o título da ata: ")
    data = input("Digite a data da reunião (dd/mm/aaaa): ")
    participantes_str = input("Digite os participantes separados por vírgula: ")
    participantes = participantes_str.split(",")
    pauta = input("Digite a pauta da reunião: ")
    decisoes = []

    print("Digite as decisões tomadas (digite 'sair' para finalizar):")
    while True:
        decisao = input()
        if decisao.lower() == "sair":
            break
        decisoes.append(decisao)

    # Opcional: Salvar a ata em um arquivo ou fazer qualquer processamento adicional

    print("\nAta emitida com sucesso!")
    print("----- Dados da Ata -----")
    print("Título:", titulo)
    print("Data:", data)
    print("Participantes:", participantes)
    print("Pauta:", pauta)
    print("Decisões:")
    for i, decisao in enumerate(decisoes):
        print(f"{i + 1}. {decisao}")



if () {
    
}
# Chamada da função de emissão de ata
emitir_ata()
