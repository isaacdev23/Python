import os
import Pesquisar as p
import csv
from datetime import date

def Fazer_Emprestimo():
    emprestimo = []
    os.system("cls")or None
    print("---------------EMPRESTIMO DE LIVROS--------------")
    nome_usuario = input("Nome do Usuário: ")
    retorno = p.Pesquisar_Cliente(nome_usuario)
    
    if retorno[0] == True:
        codigo_livro= input("Codigo livro:")
        existe = p.Pesquisar_Livro(codigo_livro)
        if existe[0] != True:
             print("Livro não existe!!")
        else:
            data_emprestimo = date.today()

            colunas =  ['cpf', 'nome de usuario', 'codigo_livro','titulo_livro','data_emprestimo' ]
            files__exists = os.path.isfile("emprestimo.csv")

            with open('emprestimo.csv', 'a', newline='', encoding='utf-8') as emprestimo_csv:
                cadastrar = csv.DictWriter(emprestimo_csv, fieldnames=colunas, delimiter=';', lineterminator='\n\r')
                if not files__exists:
                    cadastrar.writeheader()
                cadastrar.writerow({'cpf': retorno[2], 'nome_usuario':retorno[1], 'codigo_livro':existe[1], 'titulo_livro':existe[2], 'data_emprestimo':data_emprestimo})
        print("emprestimo realizado com sucesso!!!")
    else:
        print("Usuario não encontrado!!!")




def Relatório_Atrasado():
    return 0