def Listar_Clientes():
    return 0
def Listar_Livros():
    return 0
def Listar_Emprestimo():
    return 0