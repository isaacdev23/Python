import os, csv

def listar_cliente():
    clientes_csv = open('clientes.csv', encoding='utf-8')
    dados = csv.DictReader(clientes_csv,delimiter=";")

    os.system('cls') or None
    print("---------LISTAGEM DE CLIENTES---------")
    print(f'{"CPF":15}',f'{"NOME":25}', "RG")
    for clientes in dados:
        print(f'{"clientes ["cpf"]:15"}', f'{"clientes ["nome"]:25"}',clientes["rg"] )
    
    clientes_csv.close()

    listar_cliente()


    def listar_livros():
        return 0 
    

    def listar_emprestimos():
        return 0