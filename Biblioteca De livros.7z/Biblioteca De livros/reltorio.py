import csv, os
import Pesquisar 
from datetime import datetime
def relatorio_atrasados():
    emprestimos_csv = open('emprestimo.csv')

    dados_emprestimo = csv.DictReader(emprestimos_csv,delimiter= ";")

    os.system('cls') or None
    print("-----------RELATORIO DE LIVROS-----------")
    print(f'{"CPF":15}',f'{"NOME":25}',f'{"TITULO":15}', f'{"EMPRESTIMO":15}',f'{"SITUAÇÂO":10}')
    for emprestados in dados_emprestimo:
        data_emprestimo = emprestados['data_emprestimo']
        data_hoje = datetime.today()
        dias_atrasados = (data_hoje - data_emprestimo).days

        if dias_atrasados > 7:
            situacao = str("atrasado")
            print(f'{emprestados["cpf"]:15}',
                  f'{emprestados["nome"]:25}',
                  f'{emprestados["titulo_livro"]:15}',
                  f'{emprestados["data_emprestimo"]}',
                  f'{situacao:10}',
                  f'{dias_atrasados}' )
            